"""Main module of Minimize Bibfile package."""
from .checkers import general_bib_check

__all__ = [
    "general_bib_check"
]
