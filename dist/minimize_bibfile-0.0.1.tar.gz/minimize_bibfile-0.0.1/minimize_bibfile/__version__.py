"""Current version of package minimize_bibfile"""
__version__ = "0.0.1"
